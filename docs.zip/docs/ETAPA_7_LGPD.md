# ETAPA 7 — LGPD e privacidade

**Projeto:** Raízes do Nordeste — React, Vite e JavaScript.  
**Natureza:** demonstração acadêmica de Front-End, sem backend.  
**Data da execução:** 24/10/2026, das 15:33:02 às 15:33:06, horário de São Paulo.  
**Resultado:** cenários funcionais aprovados, com ressalva técnica de favicon ausente.

## 1. Objetivo da etapa

Documentar os mecanismos de privacidade já implementados e produzir evidências visuais
reais de sua execução: informação sobre os dados, preferências opcionais, consulta,
alteração, revogação, continuidade do atendimento após recusa e encerramento do Totem.

Esta etapa não certifica conformidade jurídica integral com a LGPD, segurança de produção
ou validade de um processo real de consentimento. As escolhas apresentadas são preferências
locais demonstrativas. Nenhuma lógica da aplicação foi alterada para produzir as evidências.

## 2. Código analisado e mecanismos implementados

O [REVISAO.md](../REVISAO.md) foi lido antes da execução, como referência dos requisitos e
das limitações conhecidas. Os comportamentos descritos como verificados neste documento
foram executados novamente; não foram deduzidos apenas do resultado da revisão anterior.

| Arquivo existente | Responsabilidade observada no código |
| --- | --- |
| [PrivacidadePage.jsx](../src/pages/PrivacidadePage.jsx) | Aviso, finalidades, campos opcionais, escolha salva, botões de salvar/recusar e mensagens de resultado |
| [privacidade.js](../src/data/privacidade.js) | Textos de finalidade, armazenamento e descrição das duas opções |
| [privacidadeService.js](../src/services/privacidadeService.js) | Inicia ambas as opções com `false`; aceita somente booleano `true` nas chaves conhecidas |
| [usePrivacidade.js](../src/hooks/usePrivacidade.js) | Mantém as preferências exclusivamente em memória e oferece salvar/limpar |
| [App.jsx](../src/App.jsx) | Compartilha preferências, preserva independência do checkout e chama limpeza no encerramento do atendimento |
| [persistenciaCarrinho.js](../src/services/persistenciaCarrinho.js) | Persiste somente canal, unidade e referências/quantidades do carrinho; Totem grava unidade padrão e itens vazios |
| [Rodape.jsx](../src/components/Rodape.jsx) e [ContaPage.jsx](../src/pages/ContaPage.jsx) | Disponibilizam os caminhos de consulta e alteração das preferências |

O aviso é público em `#/privacidade`, acessível sem autenticação. O formulário utiliza
`fieldset`, `legend`, labels associados implicitamente aos checkboxes e mensagens com
`role="status"`. A seleção com teclado/Espaço foi executada nesta coleta. Não foi realizada
auditoria completa de acessibilidade nem teste com leitor de tela.

## 3. Finalidade dos dados utilizados

| Dados demonstrativos | Finalidade técnica | Armazenamento e duração |
| --- | --- | --- |
| Nome/e-mail fictícios e perfil; código público de demonstração no login | Mostrar cadastro, identificação e navegação por perfil | Contas e sessão em memória. Não há senha real ou token de produção; o código não integra o registro de usuário |
| Canal, unidade, IDs de produtos e quantidades | Montar o carrinho e restaurar sua seleção no Mobile/Web | `localStorage` na chave `raizes-do-nordeste:carrinho:v1`. No Totem, o registro mantém apenas canal, unidade padrão e itens vazios |
| Número do pedido, produtos, valores e status fictícios | Simular checkout e acompanhamento | Em memória durante a sessão |
| Identificador de conta, pontos e resgates fictícios | Demonstrar fidelidade e benefícios | Em memória; sem persistência adicional no navegador |
| Booleanos `campanhas` e `estatisticas` | Demonstrar escolhas opcionais e sua alteração | Em memória; não são gravados no `localStorage` |

A aplicação orienta o uso de nomes e e-mails inventados. Não pede CPF, endereço, telefone,
localização ou dados verdadeiros de cartão. Os pagamentos são simulados e não há integração
com provedor financeiro real. A captura utilizou apenas a conta fictícia Cliente do projeto.

O armazenamento do carrinho é separado das preferências opcionais e é explicado no aviso.
A recusa dessas escolhas não desativa o funcionamento do pedido. Esta separação é uma
descrição técnica do protótipo, não uma conclusão sobre bases legais de um sistema real.

## 4. Funcionamento do consentimento demonstrativo

As opções disponíveis são:

1. **Comunicações promocionais demonstrativas:** registra a preferência nesta sessão;
   não envia mensagens, e-mails ou notificações.
2. **Estatísticas demonstrativas de uso:** simula uma escolha sobre estatísticas;
   não instala rastreadores nem transmite eventos, inclusive quando aceita.

As duas opções iniciam **desmarcadas**. Cada opção é independente. Marcar um checkbox altera
o rascunho do formulário; “Salvar preferências” confirma a escolha no estado compartilhado.
A mensagem de sucesso e o texto “Escolha salva” mostram o resultado. Sair e voltar à página
na mesma sessão permite consultar as escolhas salvas.

Nenhuma dessas opções é requisito de login, compra ou pagamento. Nesta execução, após
recusar ambas, foram efetivamente utilizados o cardápio, o carrinho e o checkout anônimo.
Não se deve interpretar essa verificação específica como uma nova execução de todos os
outros módulos da aplicação sob recusa.

## 5. Alteração e revogação

O usuário pode abrir novamente o aviso pelo rodapé ou pelo link da área da conta.
Para alterar uma escolha, marca/desmarca o checkbox correspondente e salva. Para revogar
ambas, utiliza “Recusar todas as opções”, que imediatamente salva os dois valores como
`false` e informa que as funcionalidades continuam disponíveis.

Na coleta foram executadas estas transições:

| Momento | Comunicações | Estatísticas | Verificação |
| --- | --- | --- | --- |
| Início em contexto limpo | Não aceita | Não aceita | Checkboxes e textos da escolha salva |
| Selecionar ambas e salvar | Aceita | Aceita | Mensagem de sucesso; sair e voltar preservou a escolha |
| Desmarcar estatísticas e salvar | Aceita | Não aceita | Alteração individual confirmada |
| Recusar todas | Não aceita | Não aceita | Mensagem de recusa e ambas desmarcadas |
| Após checkout aprovado | Não aceita | Não aceita | Retorno ao aviso confirmou que a recusa permanecia salva |

Recarregar a aplicação reinicia as escolhas em memória. Isso também foi executado no fim
do cenário Totem, com ambas novamente desmarcadas. Não existe registro permanente de
consentimento, recibo assinado ou sincronização dessas escolhas com servidor.

## 6. Encerramento do atendimento no Totem

O cabeçalho do canal Totem apresenta “Encerrar atendimento”. Com produtos no carrinho, abre
um diálogo para confirmar a limpeza. “Cancelar” preserva o atendimento; “Encerrar e limpar”
executa a rotina compartilhada de encerramento e retorna ao cardápio.

Para evidenciar uma limpeza real, o cenário preparou uma conta fictícia autenticada,
um produto no carrinho e **as duas preferências aceitas**. Foram realizados:

1. Abertura do diálogo de encerramento.
2. Cancelamento e confirmação de que conta, carrinho com um item e preferências aceitas
   continuavam disponíveis.
3. Nova abertura do diálogo e confirmação de “Encerrar e limpar”.
4. Verificação de `Carrinho (0)`, ausência do botão de logout, retorno de “Entrar”, canal
   Totem e unidade padrão Centro.
5. Acesso à rota da conta, que passou a pedir login, junto da mensagem de atendimento encerrado.
6. Retorno ao aviso e confirmação de ambas as preferências desmarcadas/não aceitas.
7. Leitura do armazenamento: somente carrinho vazio para o Totem, sem e-mail da conta
   ou chave de preferência opcional.

O registro observado foi:

```json
{
  "versao": 1,
  "modo": "totem",
  "unidadeId": "centro",
  "itens": []
}
```

O código também prevê limpeza de cadastros temporários, pedidos, benefícios e movimentos
de pontos nessa rotina. Nesta coleta, os estados preparados e conferidos explicitamente
no encerramento foram conta ativa, carrinho, unidade/canal e preferências; não foram
criados movimentos de pontos ou novos cadastros no Totem para produzir uma nova evidência
específica desses outros estados.

## 7. Método de obtenção das evidências

- Aplicação real em execução no servidor Vite já disponível em `http://127.0.0.1:5173`.
- Microsoft Edge **156.0.4314.42**, via Playwright, em modo headless.
- Viewport de **1440 × 1000**, escala de dispositivo 1, canais Web e Totem.
- Contexto de navegador novo, sem aproveitar preferências ou login de outra navegação.
- Cliques, seleção de canal, checkboxes, teclado/Espaço e fluxo real de pagamento simulado.
- Capturas PNG por `page.screenshot` e `locator.screenshot`: página completa, viewport
  ou o próprio formulário renderizado. Não houve montagem, imagem gerada por IA, retoque,
  alteração de CSS/DOM ou injeção de estado para forçar os resultados.
- A navegação direta para `#/conta` depois do encerramento equivale a abrir essa URL no
  navegador; não altera estado interno da aplicação.
- O script registrou arquivos, URL, instante, dimensões de viewport, tamanho e SHA-256
  das capturas em [verificacoes.json](evidencias/lgpd/verificacoes.json).

O roteiro reproduzível está em [capturar-evidencias-lgpd.cjs](../scripts/capturar-evidencias-lgpd.cjs).
Ele utiliza Playwright fornecido externamente, sem adicionar dependências ao aplicativo.
A comparação SHA-256 dos arquivos de `src` antes/depois registrou **zero alterações**.
Os nove hashes das imagens foram recalculados e conferidos com o registro.

## 8. Tabela de requisitos e evidências

| Requisito | Procedimento executado e resultado | Evidência visual |
| --- | --- | --- |
| Aviso acessível sem login | Acesso pelo link real do rodapé; título, aviso e quatro grupos de finalidade presentes | [01 — Aviso](evidencias/lgpd/01_aviso_privacidade.png) |
| Informar finalidade e armazenamento | Inspeção da página e dos quatro grupos renderizados | [01 — Aviso e finalidades](evidencias/lgpd/01_aviso_privacidade.png) |
| Não pré-selecionar consentimentos opcionais | Contexto limpo: duas opções desmarcadas e “Escolha salva: não aceita” | [02 — Estado inicial](evidencias/lgpd/02_consentimentos_desmarcados.png) |
| Selecionar e salvar preferências | Marcação, inclusive com Espaço, salvamento e consulta posterior; ambas aceitas | [03 — Preferências salvas](evidencias/lgpd/03_preferencias_salvas.png) |
| Alterar uma preferência de forma independente | Estatísticas desmarcada e salva; comunicações permaneceu aceita | [04a — Alteração individual](evidencias/lgpd/04a_alteracao_preferencias.png) |
| Revogar/recusar sem bloqueio | “Recusar todas as opções”; ambas não aceitas e mensagem de resultado | [04 — Revogação](evidencias/lgpd/04_revogacao_consentimento.png) |
| Manter funções essenciais após recusa | Uma tapioca, carrinho de R$ 18,90, confirmação e Pix demonstrativo aprovado; após o pagamento, a recusa continuava salva | [05 — Funcionamento após recusa](evidencias/lgpd/05_funcionamento_sem_consentimento.png), encadeada com [04](evidencias/lgpd/04_revogacao_consentimento.png) e o registro JSON |
| Confirmar encerramento do Totem | Diálogo exibido com conta ativa e um produto; cancelamento preservou dados; segunda tentativa confirmou | [06 — Confirmação](evidencias/lgpd/06_encerramento_totem.png) |
| Limpar conta/carrinho ao encerrar | Carrinho zero, login ausente e mensagem “Atendimento encerrado” | [07 — Sessão encerrada](evidencias/lgpd/07_sessao_totem_encerrada.png) |
| Limpar preferências do atendimento anterior | Após encerrar com escolhas aceitas, retorno ao aviso mostrou ambas desmarcadas | [08 — Preferências limpas](evidencias/lgpd/08_preferencias_totem_limpas.png) |
| Minimização e limites da demonstração | Inspeção do código e do aviso; não foram adicionados campos ou persistência para as capturas | [01](evidencias/lgpd/01_aviso_privacidade.png) e arquivos analisados na seção 2 |

Uma screenshot isolada não demonstra toda a sequência de interações. Por isso as figuras
são relacionadas ao roteiro e às asserções do registro de execução, especialmente no
checkout após recusa e na comparação antes/depois do encerramento.

## 9. Capturas reais

### Figura 1 — Aviso e finalidades

Página completa renderizada no canal Web.

![Aviso de privacidade e finalidades dos dados](evidencias/lgpd/01_aviso_privacidade.png)

### Figura 2 — Consentimentos inicialmente desmarcados

Captura do formulário real, antes de qualquer seleção.

![Consentimentos opcionais inicialmente desmarcados](evidencias/lgpd/02_consentimentos_desmarcados.png)

### Figura 3 — Preferências salvas

As duas opções aceitas e a mensagem de confirmação estão visíveis.

![Preferências selecionadas e salvas](evidencias/lgpd/03_preferencias_salvas.png)

### Figura 4a — Alteração individual

Comunicações permanece aceita; estatísticas foi revogada por desmarcação e salvamento.

![Alteração individual das preferências](evidencias/lgpd/04a_alteracao_preferencias.png)

### Figura 4 — Revogação das opções

Estado após usar “Recusar todas as opções”.

![Revogação dos consentimentos opcionais](evidencias/lgpd/04_revogacao_consentimento.png)

### Figura 5 — Uso após recusa

Pagamento demonstrativo aprovado sem autenticação e sem aceitar as opções. O pedido
fictício desta execução está identificado no PNG e no JSON, com total de R$ 18,90.

![Checkout simulado aprovado após recusar consentimentos](evidencias/lgpd/05_funcionamento_sem_consentimento.png)

### Figura 6 — Encerramento do Totem

Diálogo real com as ações de cancelar e confirmar a limpeza. Esta imagem mostra a
confirmação solicitada; o estado **depois** da limpeza está na Figura 7.

![Confirmação de encerramento do Totem](evidencias/lgpd/06_encerramento_totem.png)

### Figura 7 — Sessão encerrada

Canal Totem, carrinho vazio, ausência de autenticação e mensagem de encerramento.

![Estado da sessão após encerrar o atendimento](evidencias/lgpd/07_sessao_totem_encerrada.png)

### Figura 8 — Preferências limpas

Retorno ao formulário depois do encerramento confirmou ambas desmarcadas e não aceitas.

![Preferências limpas após encerrar o Totem](evidencias/lgpd/08_preferencias_totem_limpas.png)

## 10. Resultados, ocorrência encontrada e limites da verificação

O roteiro concluiu **11 verificações aprovadas**, sem exceções JavaScript ou requisições
HTTP externas nos contextos monitorados. O resultado geral foi registrado como
**`aprovado_com_ressalva`**, e não como execução sem ocorrências.

**Ocorrência técnica:** o navegador solicitou `http://127.0.0.1:5173/favicon.ico`, que
respondeu **404 — Not Found**. Isso gerou uma mensagem de recurso ausente no console.
O ícone de aba não estava disponível, mas os cenários funcionais foram executados sem
bloqueio. A aplicação não foi modificada para adicionar o recurso ou esconder o erro.

A primeira tentativa do roteiro interrompeu a conclusão ao exigir console sem nenhum erro.
Após identificar o recurso com a localização da mensagem no Edge, a automação foi ajustada
para registrar esse 404 como ressalva conhecida. Outros erros de console ainda fazem a
execução falhar. A segunda execução repetiu os cenários e as capturas; o JSON entregue
contém a ocorrência, o resultado final e os hashes das imagens dessa execução.

Também foi executado:

```powershell
node --test tests/operacional-privacidade.test.js
```

Resultado: **6 testes passaram, zero falhas**. Esse arquivo contém quatro testes operacionais
e dois de preferências; não se trata de seis testes exclusivamente de privacidade.
Os 44 testes mencionados no `REVISAO.md` pertencem à revisão anterior, e não foram
novamente atribuídos a esta coleta documental.

Limitações:

- Não há backend, banco de dados, trilha de auditoria durável, comprovação de identidade,
  recibo de consentimento ou gestão real de solicitações de titulares.
- Aceitar as opções não ativa comunicação promocional ou análise real de navegação.
- O estado em memória desaparece ao recarregar. O carrinho Mobile/Web é a exceção de
  persistência local informada no aviso.
- Esta coleta foi feita no Edge desktop, com viewport fixo; não foram testados aparelhos
  físicos, Totem real, outros navegadores ou leitor de tela nesta etapa.
- Os testes confirmam os cenários descritos, não a ausência universal de defeitos, a
  segurança de produção ou conformidade jurídica integral com a LGPD.
- A evidência de captura não constitui parecer jurídico ou certificação técnica.

## 11. Reprodução

Se não houver servidor disponível, em um terminal:

```powershell
npm.cmd run dev -- --host 127.0.0.1
```

Utilize a porta exibida pelo Vite. O servidor da coleta já estava ativo na porta 5173.
Em outro terminal, com Playwright externo disponível:

```powershell
$env:PLAYWRIGHT_MODULE = Join-Path $env:TEMP 'raizes-browser-check/node_modules/playwright'
$env:LGPD_BASE_URL = 'http://127.0.0.1:5173'
node scripts/capturar-evidencias-lgpd.cjs
```

O script usa Microsoft Edge instalado e cria um contexto novo. Para outra instalação
Chromium, `LGPD_BROWSER_EXECUTABLE` permite informar o caminho do executável. Se a ferramenta
externa não estiver preparada, ela pode ser instalada fora das dependências do projeto:

```powershell
npm.cmd install --prefix "$env:TEMP/raizes-browser-check" --no-package-lock --no-audit --no-fund playwright
```

Reexecutar substitui as capturas e o JSON pelos resultados da nova execução, inclusive IDs
e horários. Não reaproveite o JSON de uma execução para descrever capturas de outra.

## 12. Arquivos entregues

- `docs/ETAPA_7_LGPD.md`: documentação técnica, resultados e matriz de evidências.
- `docs/evidencias/lgpd/`: nove capturas PNG reais relacionadas nas figuras e na tabela.
- `docs/evidencias/lgpd/verificacoes.json`: execução, resultados, ressalva, URLs e hashes.
- `scripts/capturar-evidencias-lgpd.cjs`: automação reproduzível sem modificar a aplicação.

Não foram modificados os arquivos de `src`, os mocks, o `package.json` ou a lógica do
sistema para obter os resultados apresentados.
